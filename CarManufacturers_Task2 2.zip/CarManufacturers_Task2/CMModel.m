//
//  CMModel.m
//  CarManufacturers
//
//  Created by Jack Lapin on 11.09.15.
//  Copyright © 2015 Jack Lapin. All rights reserved.
//

#import "CMModel.h"

@implementation CMModel

// Insert code here to add functionality to your managed object subclass

@end
