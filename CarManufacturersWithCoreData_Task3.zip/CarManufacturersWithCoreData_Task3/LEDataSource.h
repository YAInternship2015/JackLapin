//
//  LEDataSource.h
//  CarManufacturers
//
//  Created by Jack Lapin on 05.09.15.
//  Copyright © 2015 Jack Lapin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+ApplcationPathes.h"
#import <CoreData/CoreData.h>
#import "LECMFactory+CoreDataProperties.h"

@protocol LEDataSourceDelegate;

@interface LEDataSource : NSObject <NSFetchedResultsControllerDelegate>

+ (LEDataSource*) sharedDataSource;

@property (nonatomic, strong) id<NSFetchedResultsControllerDelegate> delegate;

- (instancetype)initWithDelegate:(id<NSFetchedResultsControllerDelegate>)delegate;

- (NSUInteger)countModels;
- (LECMFactory *)modelForIndex:(NSIndexPath*)indexPath;
- (void)addnewCMWithName:(NSString *)name imageName:(NSString *)imageName;
- (void)deleteModelForIndex:(NSIndexPath *)index;


+ (void)copyPlistToAppDocumentsFolder;

@end

@protocol LEDataSourceDelegate <NSObject>

#warning чтобы появились анимации при изменении данных в базе, делегат необходимо изменить так, чтобы контроллер понимал, какое изменение происходит и что собственно необходимо анимировать. reloadData теперь недостаточно
@required
- (void)dataWasChanged:(LEDataSource *)dataSource withType: (NSFetchedResultsChangeType * ) changeType;

@end