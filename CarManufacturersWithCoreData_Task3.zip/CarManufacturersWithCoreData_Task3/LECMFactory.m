//
//  LECMFactory.m
//  CarManufacturersWithCoreData
//
//  Created by Jack Lapin on 21.09.15.
//  Copyright © 2015 Jack Lapin. All rights reserved.
//

#import "LECMFactory.h"

@implementation LECMFactory

// Insert code here to add functionality to your managed object subclass

@end
